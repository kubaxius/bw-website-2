# Astro JSON i18n

An Astro 7 integration for pathname-based locales and server-side JSON
translation catalogs.

> The package is still marked private to prevent an accidental npm publication
> while release metadata is being finalized.

## Requirements

- Node.js 22.12 or newer
- Astro 7
- String locale names and Astro pathname routing

## Installation

After the package has been published under its final name, install it in an
Astro project:

```sh
npm install @kubaxius/astro-i18n-mini
```

Inside this repository, one `npm install` at the workspace root links the demo
to the local package automatically:

```sh
npm install
npm run build
```

To test the package in a separate project before publishing, create a tarball
and install that file:

```sh
npm pack --workspace @kubaxius/astro-i18n-mini
npm install /path/to/kubaxius-astro-i18n-mini-0.1.0.tgz
```

## Setup

### 1. Add the integration

Add the integration to `astro.config.mjs`:

```js
import { defineConfig } from "astro/config";
import astroI18n from "@kubaxius/astro-i18n-mini";

export default defineConfig({
  integrations: [
    astroI18n({
      locales: ["en", "pl"],
      defaultLocale: "en",
      translations: {
        directory: "src/i18n/translations",
        onMissing: "fallback",
        warnOnMissing: true,
      },
      routing: {
        prefixDefaultLocale: true,
        redirectToDefaultLocale: true,
      },
    }),
  ],
});
```

The translation directory must be relative to the Astro project root and must
already exist. It defaults to `src/i18n/translations`.

### 2. Create JSON catalogs

Put catalogs below a directory named exactly like each configured locale:

```text
src/i18n/translations/
├── en/
│   ├── pages/index.json
│   └── common/navigation.json
└── pl/
    ├── pages/index.json
    └── common/navigation.json
```

Every file must contain a JSON object. Catalog paths are case-sensitive.

```json
{
  "heading": "Welcome",
  "intro": {
    "message": "This page is translated."
  }
}
```

When `source` is an Astro URL, `/en/` maps to `en/pages/index.json` and
`/pl/about/` maps to `pl/pages/about.json`. An explicit source such as
`common/navigation` maps to `pl/common/navigation.json` for the `pl` locale.

### 3. Add a localized route

For `src/pages/[lang]/index.astro`:

```astro
---
import {
  getCurrentLocale,
  getStaticLocalePaths,
  getTranslation,
} from "@kubaxius/astro-i18n-mini/runtime";

export const getStaticPaths = getStaticLocalePaths;

const locale = getCurrentLocale(Astro.currentLocale ?? Astro.params.lang);
const t = getTranslation({ source: Astro.url, locale });
---

<html lang={locale}>
  <body>
    <h1>{t.heading}</h1>
    <p>{t.intro.message}</p>
  </body>
</html>
```

Use `getStaticLocalePaths("locale")` when the route is named `[locale]` instead
of `[lang]`. In server output, `getStaticPaths` is not needed, but locale
validation and translation loading work the same way.

With `redirectToDefaultLocale: true`, Astro handles the redirect from `/` to the
default locale. Follow Astro's i18n routing layout when adding the root route.

Run `astro sync` after changing the configured locale list. This refreshes the
generated `Locale` type.

## Configuration reference

| Option | Default | Description |
| --- | --- | --- |
| `locales` | required | Unique, non-empty locale strings. |
| `defaultLocale` | required | One of the configured locales. |
| `translations.directory` | `src/i18n/translations` | Catalog directory relative to the project root. |
| `translations.onMissing` | `error` | Missing file and key behavior. |
| `translations.warnOnMissing` | `true` | Log each missing locale/file/key combination once per process. |
| `routing.prefixDefaultLocale` | `true` | Include the default locale in URLs. |
| `routing.redirectToDefaultLocale` | `true` | Redirect `/` to the prefixed default locale. Requires `prefixDefaultLocale`. |

## Runtime API

Import runtime values from `@kubaxius/astro-i18n-mini/runtime`:

- `locales`: the configured readonly locale tuple.
- `defaultLocale`: the configured default locale.
- `Locale`: the exact union of configured locale strings.
- `isLocale(value)`: safely narrow an unknown string to `Locale`.
- `getCurrentLocale(value)`: return a valid locale or throw a clear error.
- `getStaticLocalePaths(paramName?)`: create one static path per locale.
- `getLocalizedUrl(locale, url)`: change the locale while preserving the base
  path, query string, hash, and Astro trailing-slash behavior.
- `getTranslation(options)`: load and guard a JSON catalog.

The integration does not generate catalog-key types. If desired, describe a
catalog locally and pass it as a generic:

```ts
interface HomeTranslations {
  heading: string;
  intro: { message: string };
}

const t = getTranslation<HomeTranslations>({
  source: "pages/index",
  locale,
});
```

This generic is a developer assertion; it does not validate JSON at runtime.

`getTranslation` also accepts per-call missing behavior:

```ts
const labels = getTranslation({
  source: "common/navigation",
  locale,
  onMissing: "fallback-or-ignore",
  warnOnMissing: false,
});
```

## Missing translations

- `error`: throw when the requested file or property is missing.
- `fallback`: try the default-locale value, then throw if it is also missing.
- `ignore`: do not fall back; return `undefined` for missing properties.
- `fallback-or-ignore`: try the default locale, then return `undefined`.

Fallback is lazy for nested properties. A missing default-locale file becomes an
error only if code actually accesses a value that needs it. Arrays are atomic:
an existing locale array never borrows missing indexes from the default array.
Warnings are emitted once per locale, file, and key path in each process.

Translation loading is designed for Astro's server context and works in static
builds and SSR. It is not a client-side locale store.

## How it works

For an explanation of Astro hooks, virtual modules, catalog discovery, generated
types, development invalidation, routing, and fallback proxies, read
[BACKEND.md](./BACKEND.md).

## Release checklist

Before the first npm release, remove `private` from the package manifest, add
final repository and homepage metadata, confirm the npm name is available, run
`npm run ci`, and publish version `0.1.0` manually.
