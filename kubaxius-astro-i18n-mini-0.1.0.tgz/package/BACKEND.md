# Backend architecture

This document explains what happens behind `astroI18n()` and
`getTranslation()`. It focuses on the boundaries between the npm package, the
consumer's Astro project, Vite, and the runtime.

## The short version

The published package cannot know a consumer's locales or translation files at
package build time. The integration therefore waits for Astro to load the
consumer's configuration, validates it, and asks Vite to generate two private
modules:

```text
astro.config.mjs
       │
       ▼
 Astro integration hooks
       │
       ├── configure Astro's native i18n router
       ├── inject exact project-specific Locale types
       └── install a Vite catalog plugin
                    │
                    ├── virtual runtime configuration
                    └── virtual catalog registry ──► static JSON imports
                                                        │
                                                        ▼
                                              getTranslation() + proxies
```

The static imports are important: Vite can see every catalog during its normal
build, so the same implementation works for prerendered pages and server output.

## Package entry points

The package has two public entry points:

- `@kubaxius/astro-i18n-mini` exports the integration factory and configuration types.
- `@kubaxius/astro-i18n-mini/runtime` exports values and helpers used in Astro pages.

Build-only files such as the Vite plugin and proxy implementation are not public
entry points. This keeps the API small and allows internals to change later.

## 1. Configuration validation

Calling `astroI18n(options)` immediately passes the options through
`resolveOptions()` in `src/config.ts`. It fills defaults and rejects invalid
input before changing Astro's configuration.

Validation covers:

- at least one unique, non-empty locale;
- a default locale included in that list;
- supported missing policies and boolean values;
- a relative translation directory;
- a routing combination Astro can represent.

Path syntax is checked here, but the actual directory depends on Astro's project
root. That part happens during the setup hook.

## 2. Astro integration hooks

The integration in `src/index.ts` uses two Astro hooks.

### `astro:config:setup`

At setup time, the project root is known. The integration resolves the catalog
directory against that root and rejects normalized paths that escape it. It also
checks that the directory already exists and is a directory.

The hook then calls `updateConfig()` with:

- Astro's native `i18n` configuration for routing and redirects;
- the private Vite plugin that will expose project data to package runtime code.

Astro remains responsible for route matching, locale prefixes, redirects, and
trailing-slash policy. The package does not reproduce that router.

### `astro:config:done`

Once Astro has finalized configuration, the integration records the final base
path and injects `virtual-config.d.ts` into Astro's generated type directory.
The declaration contains the literal locale tuple. For `locales: ["en", "pl"]`,
the runtime `Locale` type becomes `"en" | "pl"`.

The package itself uses a broad build-only declaration so it can compile without
knowing a consumer project. That declaration is not shipped as the consumer's
type source; Astro generates the precise one for each project.

## 3. The virtual modules

`src/catalog-plugin.ts` implements a small Vite plugin. Runtime code imports two
IDs whose names are centralized in `src/constants.ts`:

- `virtual:astro-i18n-mini/config`
- `virtual:astro-i18n-mini/catalogs`

Vite resolves each public ID to a null-prefixed internal ID. The `\0` prefix is
a Vite/Rollup convention that marks a module as generated rather than a file on
disk.

### Runtime configuration module

The configuration module serializes only values needed at runtime: locales,
default locale, base path, and missing-translation settings. This avoids reading
or importing the consumer's `astro.config.mjs` from published package code.

### Catalog registry module

When Vite loads the registry, `scanCatalogs()` finds all JSON files recursively.
It validates each file and produces deterministic source equivalent to:

```js
import catalog0 from "/project/src/i18n/translations/en/pages/index.json";
import catalog1 from "/project/src/i18n/translations/pl/pages/index.json";

export default {
  "en/pages/index.json": catalog0,
  "pl/pages/index.json": catalog1,
};
```

Registry keys always use `/`, including on Windows, and the sorted file order
makes generated output stable. Catalog validation ensures valid JSON, an object
at the top level, and a first directory segment matching a configured locale.
Catalog key casing is not normalized.

## 4. Development updates

Vite normally watches imported catalog files, but an added file does not yet
appear in the generated import list and a removed file must disappear from it.
The plugin therefore watches the whole catalog directory.

An add, change, or remove event for a JSON file invalidates the virtual registry
and sends a full reload. On the next load, the directory is scanned again and a
new registry is generated. Non-JSON changes are ignored.

## 5. Translation lookup

`getTranslation()` in `src/runtime/translation.ts` first normalizes its source:

- an Astro URL becomes a page catalog such as `pages/about`;
- an explicit source such as `common/navigation.json` becomes
  `common/navigation`;
- empty names and `.` or `..` segments are rejected.

It combines the locale, normalized source, and `.json` suffix to look up the
catalog in the virtual registry. If the selected missing policy supports
fallback, it also looks up the same catalog for the default locale.

The default file is not required merely because fallback is configured. It only
matters when the requested locale is missing a file or a property that needs a
fallback value.

## 6. Lazy property handling

Loaded objects are wrapped by the proxies in
`src/runtime/translation-proxy.ts`. A proxy allows the package to detect a
missing nested property at the moment application code reads it:

```ts
t.footer.contact.label
```

At each step, the proxy follows the same path through the selected locale and,
when enabled, the default locale. This supports nested object fallback without
eagerly merging catalogs.

There are two deliberate boundaries:

- If the selected value is an object but the fallback value has a different
  shape, deeper access stops using that fallback.
- Arrays are atomic. Once a locale provides an array, its missing indexes do not
  fall back to another locale's array.

Symbols and `toJSON` pass directly through the proxy because they are JavaScript
protocol operations, not translation keys. Warnings are deduplicated with a
process-level set keyed by locale, file, and property path.

## 7. Routing helpers and base paths

`src/runtime/routing.ts` delegates localized pathname generation to
`astro:i18n`. Before doing so, it removes the configured Astro base and the
existing locale prefix. After Astro generates the localized path, it restores
the base exactly once. Query strings and hashes are appended unchanged.

This ordering matters for a site deployed below a path such as `/docs`: Astro's
locale helper should receive `guide/start`, not `/docs/en/guide/start`.

`getStaticLocalePaths()` creates a route parameter for every configured locale.
It defaults to `lang`, but an explicit argument supports routes such as
`[locale]`. It also tolerates Astro passing a context object when the helper is
assigned directly as `getStaticPaths`.

## 8. Static builds and SSR

The catalogs are normal Vite imports by the time application code runs. Static
builds evaluate `getTranslation()` while prerendering, while SSR evaluates it in
the server bundle for each request. No filesystem read is needed in either
runtime path.

Translation APIs are intended for Astro's server-side frontmatter. The package
does not currently provide a hydrated client store, catalog-key generation,
locale aliases, domain routing, custom loaders, or non-JSON catalogs.

## Source map

| File | Responsibility |
| --- | --- |
| `src/index.ts` | Astro integration lifecycle and injected types |
| `src/config.ts` | Option defaults and validation |
| `src/catalog-plugin.ts` | Catalog discovery, virtual modules, and dev watching |
| `src/constants.ts` | Central virtual IDs and integration name |
| `src/runtime/runtime-config.ts` | Typed access to serialized project settings |
| `src/runtime/translation.ts` | Source normalization and catalog selection |
| `src/runtime/translation-proxy.ts` | Lazy missing-key and fallback behavior |
| `src/runtime/routing.ts` | Locale validation, static paths, and localized URLs |
| `src/types.ts` | Public and internal configuration/catalog types |

## Verification

The workspace tests validation, catalog scanning, every missing policy, nested
fallback, type mismatches, nulls, arrays, warning deduplication, routing helpers,
static output, live SSR, generated types, development invalidation, and a packed
tarball installed into an isolated Astro fixture.

Run the complete suite from the repository root:

```sh
npm run ci
```
